HOTELPRO — WEB QUẢN LÝ KHÁCH SẠN (BẢN DEMO)

Cách chạy:
1. Giải nén file ZIP.
2. Mở thư mục quan_ly_khach_san.
3. Nhấp đúp vào index.html để mở bằng Chrome, Edge hoặc Firefox.

Chức năng:
- Tổng quan tình trạng phòng và doanh thu.
- Quản lý phòng: thêm, đổi trạng thái, xóa.
- Quản lý đặt phòng: tạo đặt phòng, cập nhật trạng thái.
- Danh sách khách hàng.
- Báo cáo doanh thu và xuất CSV.
- Lưu dữ liệu trong localStorage của trình duyệt.

Lưu ý:
Đây là bản demo frontend, không cần cài đặt. Dữ liệu lưu trên trình duyệt đang dùng.
Chưa có backend, cơ sở dữ liệu dùng chung, đăng nhập/phân quyền hoặc tích hợp thanh toán.
